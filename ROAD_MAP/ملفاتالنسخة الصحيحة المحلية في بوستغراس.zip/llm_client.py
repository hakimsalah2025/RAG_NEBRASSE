# llm_client.py
from openai import OpenAI
import os
from dotenv import load_dotenv

# تحميل متغيرات البيئة
load_dotenv()

# إنشاء العميل
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_from_llm(prompt: str, system_prompt: str = None) -> str:
    """
    دالة موحدة للتوليد النصي عبر OpenAI GPT-4o-mini
    """
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages
    )

    return response.choices[0].message.content.strip()


if __name__ == "__main__":
    print(generate_from_llm("اكتب فقرة قصيرة بالعربية عن الذكاء الاصطناعي."))
